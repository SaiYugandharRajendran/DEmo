package com.example.demo.controller;

import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.GeneralResponse;
import com.example.demo.model.User;
import com.example.demo.service.MD5UserService;

@RestController
@RequestMapping(value="/api/v1/md5")
public class MD5UserController {
	
	@Autowired
	private MD5UserService service;
	
	@GetMapping("/getAllUsers")
	public ResponseEntity<?> getAll() throws InvalidKeyException, NoSuchPaddingException, 
	NoSuchAlgorithmException, InvalidAlgorithmParameterException, ClassNotFoundException, 
	IllegalBlockSizeException, BadPaddingException, IOException{
		return new ResponseEntity<List<User>>(service.getUsers(),HttpStatus.OK);
	}
	@PostMapping("/createUser")
	public ResponseEntity<?> create(@RequestBody User user) throws InvalidKeyException, 
	NoSuchAlgorithmException, NoSuchPaddingException, InvalidAlgorithmParameterException, 
	IllegalBlockSizeException, IOException, BadPaddingException{
		GeneralResponse response = service.addUser(user);
		return new ResponseEntity<GeneralResponse>(response,HttpStatus.CREATED);
	}

}
