package com.example.demo.dto;

import com.example.demo.model.User;
import com.example.demo.util.MD5EncryptionDecryption;

public class MD5UserDto {
	
	final String secretKey = "thisisdemoforMD5AG";
	
	public User md5Decrypt(User user) {
		MD5EncryptionDecryption util = new MD5EncryptionDecryption();
		User n = new User();
		n.setId(user.getId());
		n.setPassword(util.decryptMD5(user.getPassword(), secretKey));
		n.setUserName(util.decryptMD5(user.getUserName(), secretKey));
		return n;
	}
	
	public User md5Encrypt(User user) {
		MD5EncryptionDecryption util = new MD5EncryptionDecryption();			
		User u = new User();
		u.setId(user.getId());
		u.setPassword(util.encryptMD5(user.getPassword(), secretKey));
		u.setUserName(util.encryptMD5(user.getUserName(), secretKey));
		return u;
	}

}
