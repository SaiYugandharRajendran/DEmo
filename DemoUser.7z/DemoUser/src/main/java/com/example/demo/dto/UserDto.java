package com.example.demo.dto;

import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;

import com.example.demo.model.User;
import com.example.demo.util.EncryptionDecryptionUtil;

public class UserDto {
	
	private static EncryptionDecryptionUtil util = new EncryptionDecryptionUtil();	
	private static final IvParameterSpec ivParameterSpec = util.generateIv();
	private static final String key = "7c1kAgK2y6CU9QScCqR1Ww==";
	private static final String algorithm = "AES/CBC/PKCS5Padding";
	
	public User encryptUser(User user) throws InvalidKeyException, NoSuchPaddingException, 
	NoSuchAlgorithmException, InvalidAlgorithmParameterException, IllegalBlockSizeException, 
	BadPaddingException, IOException {
		SecretKey SecretKey = util.convertStringToSecretKey(key);
		User encrypted = new User();
		encrypted.setId(user.getId());
		encrypted.setPassword(util.encryptObject(algorithm, user.getPassword(), SecretKey, ivParameterSpec));
		encrypted.setUserName(util.encryptObject(algorithm, user.getUserName(), SecretKey, ivParameterSpec));
		return encrypted;
	}
	
	public User decryptUser(User user) throws InvalidKeyException, NoSuchPaddingException, 
	NoSuchAlgorithmException, InvalidAlgorithmParameterException, ClassNotFoundException, 
	IllegalBlockSizeException, BadPaddingException, IOException {
		SecretKey SecretKey = util.convertStringToSecretKey(key);
		User decrypted = new User();
		decrypted.setId(user.getId());
		decrypted.setPassword(util.decryptObject(algorithm, user.getPassword(), SecretKey, ivParameterSpec));
		decrypted.setUserName(util.decryptObject(algorithm, user.getUserName(), SecretKey, ivParameterSpec));
		return decrypted;
	}

}
