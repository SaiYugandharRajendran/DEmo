package com.example.demo.service;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SealedObject;
import javax.crypto.SecretKey;

import org.bouncycastle.util.Arrays;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import com.example.demo.dto.UserDto;
import com.example.demo.model.GeneralResponse;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import com.example.demo.util.EncryptionDecryptionUtil;

@Service
public class UserService {
	@Autowired
	private UserRepository repo;
	
	private static EncryptionDecryptionUtil util = new EncryptionDecryptionUtil();	
	private static final IvParameterSpec ivParameterSpec = util.generateIv();
	private static final String key = "daW7Pj/lz+1wAP1IHEgvcX6IRQBBcZT3QFj+yu7PX2r";
	private static final String algorithm = "AES/CBC/PKCS5Padding";
	
	public List<User> getUsers() throws InvalidKeyException, NoSuchPaddingException, 
	NoSuchAlgorithmException, InvalidAlgorithmParameterException, ClassNotFoundException, 
	IllegalBlockSizeException, BadPaddingException, IOException{
		Optional<List<User>> users = Optional.ofNullable(repo.findAll());
		if(users.isPresent()) {
			List<User> decryptedUsers = new ArrayList<>();			
			users.get().stream().forEach(item->{
				User n = new User();
				n.setId(item.getId());
				SecretKey SecretKey = util.convertStringToSecretKey(key);
				try {
					n.setPassword(util.decryptObject(algorithm, item.getPassword(), SecretKey, ivParameterSpec));
					n.setUserName(util.decryptObject(algorithm, item.getUserName(), SecretKey, ivParameterSpec));
				} catch (InvalidKeyException | NoSuchPaddingException | NoSuchAlgorithmException
						| InvalidAlgorithmParameterException | ClassNotFoundException | IllegalBlockSizeException
						| BadPaddingException | IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}				
				decryptedUsers.add(n);
			});
			return decryptedUsers;
		}
		return null;
	}
	
	public GeneralResponse addUser(User user) throws InvalidKeyException, NoSuchPaddingException, 
	NoSuchAlgorithmException, InvalidAlgorithmParameterException, IllegalBlockSizeException, 
	BadPaddingException, IOException{
		GeneralResponse response = validate(user);		
		if(response.getMessage()==null) {	
			UserDto dto = new UserDto();
			repo.saveAndFlush(dto.encryptUser(user));
			response.setCode(200);
			response.setMessage("Record created");
		}
		return response;
	}
	
	private GeneralResponse validate(User user) {
		GeneralResponse response = new GeneralResponse();
		response.setCode(400);
		if(user.getUserName()==null || user.getUserName().isEmpty()) {
			response.setMessage("User name cannot be null or empty");
		}
		if(user.getPassword()==null || user.getPassword().isEmpty()) {
			response.setMessage("Password cannot be null or empty");
		}
		return response;
	}
	
}
