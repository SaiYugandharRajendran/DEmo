package com.example.demo.service;

import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.MD5UserDto;
import com.example.demo.dto.UserDto;
import com.example.demo.model.GeneralResponse;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import com.example.demo.util.MD5EncryptionDecryption;

@Service
public class MD5UserService {
	
	@Autowired
	private UserRepository repo;
	
	public List<User> getUsers() throws InvalidKeyException, NoSuchPaddingException, 
	NoSuchAlgorithmException, InvalidAlgorithmParameterException, ClassNotFoundException, 
	IllegalBlockSizeException, BadPaddingException, IOException{
		Optional<List<User>> users = Optional.ofNullable(repo.findAll());
		if(users.isPresent()) {
			List<User> decryptedUsers = new ArrayList<>();			
			users.get().stream().forEach(item->{
				MD5UserDto dto = new MD5UserDto();
				decryptedUsers.add(dto.md5Decrypt(item));
			});
			return decryptedUsers;
		}
		return null;
	}
	
	public GeneralResponse addUser(User user) throws InvalidKeyException, NoSuchPaddingException, 
	NoSuchAlgorithmException, InvalidAlgorithmParameterException, IllegalBlockSizeException, 
	BadPaddingException, IOException{
		GeneralResponse response = validate(user);		
		if(response.getMessage()==null) {
			MD5UserDto dto = new MD5UserDto();
			repo.saveAndFlush(dto.md5Encrypt(user));
			response.setCode(200);
			response.setMessage("Record created");
		}
		return response;
	}
	
	private GeneralResponse validate(User user) {
		GeneralResponse response = new GeneralResponse();
		response.setCode(400);
		if(user.getUserName()==null || user.getUserName().isEmpty()) {
			response.setMessage("User name cannot be null or empty");
		}
		if(user.getPassword()==null || user.getPassword().isEmpty()) {
			response.setMessage("Password cannot be null or empty");
		}
		return response;
	}

}
