package com.example.demo.util;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.bouncycastle.util.Arrays;

public class MD5EncryptionDecryption {	

	private static SecretKeySpec secretKey;
	private static byte[] key1;
	
	public static void setKey(String myKey) {
		try {
			key1 = myKey.getBytes("UTF-8");
			MessageDigest sha = MessageDigest.getInstance("SHA-1");
			key1 = sha.digest(key1);
			key1 = Arrays.copyOf(key1, 16);
			secretKey = new SecretKeySpec(key1,"AES");
		}catch(NoSuchAlgorithmException e) {
			
		}catch(UnsupportedEncodingException e) {
			
		}
	}
	
	public static String encryptMD5(String strToEnc, String sec) {
		try {
			setKey(sec);
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, secretKey);
			return Base64.getEncoder().encodeToString(cipher.doFinal(strToEnc.getBytes("UTF-8")));
		}catch(Exception e) {
			
		}
		return null;
	}
	
	public static String decryptMD5(String strToDec, String sec) {
		try {
			setKey(sec);
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			cipher.init(Cipher.DECRYPT_MODE, secretKey);
			return new String(cipher.doFinal(Base64.getDecoder().decode(strToDec)));
		}catch(Exception e) {
			
		}
		return null;
	}
}
