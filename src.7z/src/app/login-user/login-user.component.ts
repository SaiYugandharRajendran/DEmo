import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login-user',
  templateUrl: './login-user.component.html',
  styleUrls: ['./login-user.component.css']
})
export class LoginUserComponent implements OnInit {
  
  user: User = new User();
  userName: string="";
  password: string="";
  show: boolean=false; 

  constructor(private userService: UserService, private router: Router) { }

  ngOnInit(): void {
  }

  loginUser(){
    this.router.navigate(['/users']);
  }

  signup(){
    this.router.navigate(['/create-user']);
  }

  home(){
    this.router.navigate(['/home']);
  }

  async onSubmit(){
    const response = await fetch('http://localhost:8081/api/v1/consumer/getAllUsers');
    const data: User[] = await response.json();
    for(var user of data){
      if(this.userName === user.userName && this.password === user.password){
        this.show=true;
      }
    } 
    if(this.show && this.userName=="admin" && this.password=="admin"){
      this.loginUser();
    }else if(this.show){
      this.home();
    }else{
      window.alert("Invalid credentials");
    }
  }

}
