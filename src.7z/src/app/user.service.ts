import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private baseUrl = "http://localhost:8081/api/v1/consumer/getAllUsers";
  private create = "http://localhost:8081/api/v1/consumer/createUser";
  constructor(private httpclient: HttpClient) { }
  getUserList(): Observable<User[]>{
    return this.httpclient.get<User[]>(`${this.baseUrl}`);
  }

  createUser(user: User): Observable<Object>{
    return this.httpclient.post(`${this.create}`,user);
  }

}
