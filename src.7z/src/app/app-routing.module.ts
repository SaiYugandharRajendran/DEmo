import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserListComponent } from './user-list/user-list.component';
import { CreateUserComponent } from './create-user/create-user.component';
import { LoginUserComponent } from './login-user/login-user.component';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
  {path:'login-user', component: LoginUserComponent},
  {path:'users', component: UserListComponent},
  {path:'create-user', component: CreateUserComponent},  
  {path:'home', component: HomeComponent},
  {path:'', redirectTo:'login-user', pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
