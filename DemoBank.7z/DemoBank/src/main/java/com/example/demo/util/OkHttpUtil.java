package com.example.demo.util;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class OkHttpUtil {
	
private final OkHttpClient httpClient = new OkHttpClient();
	
	public String getDataFromAPI(String apiUrl) throws Exception {
        Request request = new Request.Builder()
                .url(apiUrl)
                .build();
        try (Response response = httpClient.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new Exception("Request failed with HTTP error code: " + response.code());
            }

            return response.body().string();
        }
    }
	
	public String postDataToAPI(String apiUrl, String requestBodyJson) throws Exception {
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody requestBody = RequestBody.create(requestBodyJson, mediaType);        
        Request request = new Request.Builder()
                .url(apiUrl)
                .post(requestBody)
                .build();
        try (Response response = httpClient.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new Exception("Request failed with HTTP error code: " + response.code());
            }
            return response.body().string();
        }
    }

}
