package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.demo.model.GeneralResponse;
import com.example.demo.model.User;
import com.example.demo.util.OkHttpUtil;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.MediaType;
import okhttp3.RequestBody;

@Service
public class UserService {
	
	public List<User> getUsers() {
		try {
			OkHttpUtil util = new OkHttpUtil();
			String output = util.getDataFromAPI("http://localhost:8080/api/v1/md5/getAllUsers");
			ObjectMapper objectMapper = new ObjectMapper();
			List<User> users = objectMapper.readValue(output, new TypeReference<List<User>>() {});
			return users;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public GeneralResponse addUser(User user) {
		try {
			OkHttpUtil util = new OkHttpUtil();
			ObjectMapper objectMapper = new ObjectMapper();
	        String jsonString = objectMapper.writeValueAsString(user);
	        String output = util.postDataToAPI("http://localhost:8080/api/v1/md5/createUser",jsonString);
	        GeneralResponse response = objectMapper.readValue(output, GeneralResponse.class);
	        return response;
		}catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
